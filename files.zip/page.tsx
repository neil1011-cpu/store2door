/* eslint-disable @next/next/no-img-element */
import Link from 'next/link';
import { Sora, DM_Sans } from 'next/font/google';
import './landing.css';
import { Header, TrackingCard } from './landing-client';

// Change these two if your app uses different routes.
const LOGIN_HREF = '/login';
const REGISTER_HREF = '/register';

const sora = Sora({ subsets: ['latin'], weight: ['600', '700', '800'], variable: '--font-sora' });
const dm = DM_Sans({ subsets: ['latin'], weight: ['400', '500', '700'], variable: '--font-dm' });

export const metadata = {
  title: 'From Store 2 Door - Shipping Services from Store to Door',
  description:
    'Reliable shipping straight from the store to your door. Get your own USA shipping address and enjoy convenient delivery options.',
};

export default function HomePage() {
  return (
    <div className={`landing ${sora.variable} ${dm.variable}`} id="top">
      <Header loginHref={LOGIN_HREF} registerHref={REGISTER_HREF} />

      <main>
        <section className="hero">
          <div className="wrap">
            <div>
              <p className="tag">Shipping to Jamaica from Portmore</p>
              <h1>From the store to your door, <em>hassle free.</em></h1>
              <p>Sign up for a free USA shipping address, shop any online store, and we will get your packages home by air or sea.</p>
              <div className="cta">
                <Link className="btn" href={REGISTER_HREF}>Sign up for free</Link>
                <a className="btn ghost" href="#services">See our services</a>
              </div>
            </div>
            <TrackingCard />
          </div>
        </section>

        <div className="badges">
          <div><b>Fast shipping</b><span>Weekly air freight</span></div>
          <div><b>Secure process</b><span>Checked before delivery</span></div>
          <div><b>Customer support</b><span>Call or WhatsApp</span></div>
          <div><b>Top rated</b><span>Loved by our customers</span></div>
        </div>

        <section id="journey">
          <div className="wrap">
            <div className="head"><p className="tag">Our simple process</p><h2>Follow your package from the store to your door</h2></div>
            <div className="journey">
              <div className="stop"><i>1</i><h3>Package received</h3><p>We receive and process your orders at our warehouse facility.</p></div>
              <div className="stop"><i>2</i><h3>In transit</h3><p>Your items are securely transported by air or sea freight.</p></div>
              <div className="stop"><i>3</i><h3>Quality check</h3><p>We verify all items for condition and accuracy before delivery.</p></div>
              <div className="stop"><i>4</i><h3>Delivery</h3><p>Your packages arrive at your door or wait for you to pick up.</p></div>
            </div>
          </div>
        </section>

        <section id="services" className="alt">
          <div className="wrap">
            <div className="head"><p className="tag">Our services</p><h2>Shipping and logistics built around your shopping</h2><p>Everything you need to buy from stores abroad and bring it home.</p></div>
            <div className="grid">
              <article className="svc">
                <img src="/images/air-freight.jpg" alt="Airplane taking off" style={{ objectPosition: '50% 58%' }} loading="lazy" />
                <div><small>Weekly shipping</small><h3>Air freight</h3><p>Fast, efficient transit on our regular weekly schedule for your small to medium size packages.</p>
                  <ul><li>Weekly shipping schedule</li><li>Fast and efficient transit</li><li>Ideal for small to medium packages</li></ul></div>
              </article>
              <article className="svc">
                <img src="/images/sea-freight.jpg" alt="Container ship at sea" style={{ objectPosition: '50% 45%' }} loading="lazy" />
                <div><small>Commercial and personal</small><h3>Sea freight</h3><p>Courier and logistics solutions by sea, from the store straight to your door.</p>
                  <ul><li>Commercial and personal shipping</li><li>Complete logistics solutions</li><li>Store to door delivery</li></ul></div>
              </article>
              <article className="svc">
                <img src="/images/credit-card-service.jpg" alt="Credit cards" loading="lazy" />
                <div><small>Shop online anywhere</small><h3>Credit card service</h3><p>No credit card? Use ours to make your online purchases.</p>
                  <ul><li>No personal credit card needed</li><li>Shop at any online store</li><li>Secure payment handling</li></ul></div>
              </article>
              <article className="svc">
                <img src="/images/product-search.jpg" alt="Laptop showing an online shopping cart" style={{ objectPosition: '50% 72%' }} loading="lazy" />
                <div><small>Best price guarantee</small><h3>Product search assistance</h3><p>We help you find the right product at the right price.</p>
                  <ul><li>Expert product research</li><li>Best price comparisons</li><li>Personalized shopping assistance</li></ul></div>
              </article>
            </div>
          </div>
        </section>

        <section id="how-it-works">
          <div className="wrap">
            <div className="head"><p className="tag">How it works</p><h2>Three steps to your door</h2><p>Shipping from sign-up to pickup, without the hassle.</p></div>
            <div className="three">
              <div><b>1</b><h3>Sign up</h3><p>Register and receive your USA shipping address free of cost.</p><Link href={REGISTER_HREF}>Get started</Link></div>
              <div><b>2</b><h3>Shop online</h3><p>Shop at any of your favourite stores. We collect and prepare your items for shipping.</p></div>
              <div><b>3</b><h3>Pick up your packages</h3><p>Get notified about your package status, then request delivery or pick up in store.</p></div>
            </div>
          </div>
        </section>

        <section className="alt">
          <div className="wrap">
            <div className="head"><p className="tag">Testimonials</p><h2>What our customers say</h2></div>
            <div className="three">
              <blockquote className="quote"><p>The rates are competitive and I always receive my packages on time. Their customer service is exceptional and they have never let me down.</p><b>Shanda James</b><span>Loyal customer</span></blockquote>
              <blockquote className="quote"><p>The staff is friendly and courteous and makes their customers feel welcome. I have been using their service for years and could not be happier.</p><b>Karissa Campbell</b><span>Regular customer</span></blockquote>
              <blockquote className="quote"><p>The service is efficient and the wait time is short, so I can just grab my packages and go. Their tracking system keeps me informed every step of the way.</p><b>Samantha Allen</b><span>Business customer</span></blockquote>
            </div>
          </div>
        </section>

        <section>
          <div className="wrap">
            <div className="head"><p className="tag">Global shopping</p><h2>Shop from the world&rsquo;s most trusted online stores</h2><p>From USA retailers to Chinese manufacturers, we ship from anywhere to Jamaica.</p></div>
            <div className="stores"><span>Amazon</span><span>Instacart</span><span>eBay</span><span>Shopify</span><span>Etsy</span></div>
          </div>
        </section>

        <section className="final">
          <div className="wrap">
            <h2>Ready to start shipping?</h2>
            <p>Sign up today and enjoy hassle-free global shipping with our door-to-door service.</p>
            <div className="cta"><Link className="btn" href={REGISTER_HREF}>Sign up for free</Link></div>
          </div>
        </section>
      </main>

      <footer>
        <div className="wrap">
          <div className="fg">
            <div><h4>From Store 2 Door Shipping Services</h4><p>Providing reliable shipping services straight from the store to your door, hassle free.</p></div>
            <div><h4>Quick links</h4><ul><li><a href="#services">Services</a></li><li><a href="#how-it-works">How it works</a></li><li><Link href={LOGIN_HREF}>Login</Link></li><li><Link href={REGISTER_HREF}>Register</Link></li></ul></div>
            <div><h4>Contact info</h4><ul><li>Portmore, St. Catherine</li><li>Flow: <a href="tel:+18767713071">(876) 771-3071</a></li><li>Digicel: <a href="tel:+18765069727">(876) 506-9727</a></li></ul></div>
          </div>
          <p className="copy">&copy; 2026 From Store 2 Door Shipping Services | All Rights Reserved</p>
        </div>
      </footer>
    </div>
  );
}
